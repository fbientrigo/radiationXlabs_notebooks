# radbin — Fluence-Scaled Poisson Binning

Implements a reset-aware, fluence-scaled binning pipeline to estimate radiation-normalized failure rates with exact Poisson (Garwood) CIs, plus CLI, plots, and tests.

## Install
```bash
pip install -r requirements.txt
```

## Run on synthetic data
```bash
python analyze.py --synth --out-prefix out/synth --n-bins-flu 24 --target-N 80 --min-events 5
```

## Run on CSVs
```bash
python analyze.py   --beam tests/data/beam_example.csv   --fails tests/data/fails_example.csv   --area-run 16 --area-ref 32   --n-bins-flu 24 --target-N 80 --min-events 5   --alpha 0.32   --out-prefix out/run2
```

This will write:
- `out_prefix_{wall|fluence|eqN}.csv` with per-bin stats (`t_start,t_end,N,T,rate,lo,hi,t_mid,width_s`)
- PNG plots: cumulative, wall, fluence, equal-count, and scaling-ratio
- GLM slope & p-value for wall vs. fluence views

### Area normalization
If run2 used 16 subsystems and run3 used 32, compare them at equal effective area by passing the run's area and your chosen reference:
```
--area-run 16 --area-ref 32    # scales rates by 32/16 = 2×
```

## API (import from `radbin`)
- `to_datetime_smart(series)` — robust parser
- `compute_scaled_time_clipped(…)` — adds `dt_eq`, `t_eq`, `scale_ratio`
- `extract_event_times(fails_df)` — one timestamp per increment of cumulative counter
- `detect_resets(…)`, `build_bins_reset_locked(…)`
- `build_bins_equal_fluence(…)`, `build_bins_equal_count(…)`
- `garwood_rate_ci(N, T, alpha)` — exact CI on λ
- `build_and_summarize(…)` — orchestrates everything and returns a DataFrame
- `poisson_trend_test(df_stats)` — GLM Poisson slope with offset log(T)

## Plots
- **Cumulative**: sanity-check for monotonicity and resets.
- **Wall (reset-locked)**: rates binned by reset windows, `T` is wall time.
- **Fluence**: equal `Δt_eq` bins; if the device is in plateau, rates should look stationary.
- **Equal-count**: roughly constant precision because `σ_rel ≈ 1/√N`.

## Tests
Run:
```bash
pytest -q
```
The acceptance test covers conservation of event counts, CI containment, scaling caps, and a trend sanity check.

---

© 2025 radbin
