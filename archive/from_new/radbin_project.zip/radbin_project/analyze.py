\
#!/usr/bin/env python3
import argparse, os
import numpy as np
import pandas as pd
from radbin.core import (
    to_datetime_smart, compute_scaled_time_clipped, extract_event_times,
    build_and_summarize, inspect_scaled_time, plot_cumulative_fails,
    errorbar_rates, plot_scaling_ratio
)
from radbin.glm import poisson_trend_test
from radbin.synth import synth_beam, synth_fails_from_hazard
import matplotlib.pyplot as plt

def load_csv_or_none(path):
    if path is None:
        return None
    return pd.read_csv(path)

def main():
    ap = argparse.ArgumentParser(description="Fluence-Scaled Poisson Binning Analysis")
    ap.add_argument("--beam", type=str, help="Beam CSV path")
    ap.add_argument("--fails", type=str, help="Fails CSV path")
    ap.add_argument("--area-run", type=int, default=32, help="Effective area of this run")
    ap.add_argument("--area-ref", type=int, default=32, help="Reference area to normalize to")
    ap.add_argument("--n-bins-flu", type=int, default=30, help="Number of fluence-scaled bins")
    ap.add_argument("--n-bins-wall", type=int, default=30, help="(unused) for potential wall-time bins")
    ap.add_argument("--target-N", type=int, default=100, help="Target events per equal-count bin")
    ap.add_argument("--min-events", type=int, default=5, help="Minimum events per bin (merging)")
    ap.add_argument("--alpha", type=float, default=0.32, help="Garwood CI tail probability")
    ap.add_argument("--out-prefix", type=str, default="out/run", help="Prefix for output files")
    ap.add_argument("--synth", action="store_true", help="Use synthetic data instead of CSVs")
    args = ap.parse_args()

    if args.synth:
        beam = synth_beam()
        fails = synth_fails_from_hazard(beam, hazard_mode="bathtub", plateau_level=0.01, rate_scale=0.6, reset_every_s=1800)
    else:
        beam = load_csv_or_none(args.beam)
        fails = load_csv_or_none(args.fails)
        if beam is None or fails is None:
            raise SystemExit("Both --beam and --fails must be provided unless --synth is set")

    # Normalize columns
    for df in (beam, fails):
        if "time" in df.columns:
            df["time"] = to_datetime_smart(df["time"])

    # Inspect scaling
    beq = compute_scaled_time_clipped(beam)
    inspect_scaled_time(beq, label="beam")

    # Build three views
    area_norm = (args.area_run, args.area_ref)

    # 1) Reset-locked (wall-time or beam-scaled T depending on T_source)
    res_wall = build_and_summarize(beam, fails, bin_mode="reset", k_multiple=1,
                                   area_norm=area_norm, alpha=args.alpha, T_source="wall",
                                   min_events_per_bin=args.min_events)
    res_wall.to_csv(f"{args.out_prefix}_wall.csv", index=False)

    # 2) Fluence-scaled equal-teq bins
    res_flu = build_and_summarize(beam, fails, bin_mode="fluence", n_bins=args.n-bins_flu if hasattr(args,'n-bins_flu') else args.n_bins_flu,
                                  area_norm=area_norm, alpha=args.alpha, T_source="beam",
                                  min_events_per_bin=args.min_events)
    # fix above attribute (argparse hyphen name handling)
    if res_flu is None or len(res_flu)==0:
        res_flu = build_and_summarize(beam, fails, bin_mode="fluence", n_bins=args.n_bins_flu,
                                      area_norm=area_norm, alpha=args.alpha, T_source="beam",
                                      min_events_per_bin=args.min_events)
    res_flu.to_csv(f"{args.out_prefix}_fluence.csv", index=False)

    # 3) Equal-count bins
    res_eqN = build_and_summarize(beam, fails, bin_mode="count", target_N=args.target_N,
                                  area_norm=area_norm, alpha=args.alpha, T_source="beam",
                                  min_events_per_bin=args.min_events)
    res_eqN.to_csv(f"{args.out_prefix}_eqN.csv", index=False)

    # Plots
    plot_cumulative_fails(fails, title="Cumulative fails")
    plt.savefig(f"{args.out_prefix}_cum.png", dpi=150)
    plt.close()

    errorbar_rates(res_wall, title="Rates — reset-locked (wall time T)")
    plt.savefig(f"{args.out_prefix}_wall_rates.png", dpi=150)
    plt.close()

    errorbar_rates(res_flu, title="Rates — equal scaled time (fluence)")
    plt.savefig(f"{args.out_prefix}_fluence_rates.png", dpi=150)
    plt.close()

    errorbar_rates(res_eqN, title="Rates — equal-count bins")
    plt.savefig(f"{args.out_prefix}_eqN_rates.png", dpi=150)
    plt.close()

    plot_scaling_ratio(beam, label="Scaling ratio dt_eq/dt")
    plt.savefig(f"{args.out_prefix}_scaleratio.png", dpi=150)
    plt.close()

    # GLM trend tests
    tr_wall = poisson_trend_test(res_wall, x_col="t_mid")
    tr_flu  = poisson_trend_test(res_flu,  x_col="t_mid")
    print("GLM trend (WALL): slope_per_hour=%.4g, p=%.3g, AIC=%.1f" % (tr_wall["slope_per_hour"], tr_wall["p_value"], tr_wall["AIC"]))
    print("GLM trend (FLU ): slope_per_hour=%.4g, p=%.3g, AIC=%.1f" % (tr_flu["slope_per_hour"], tr_flu["p_value"], tr_flu["AIC"]))

if __name__ == "__main__":
    main()
